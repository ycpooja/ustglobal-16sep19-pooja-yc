package com.ustglobal.contact.dao;

import lombok.Data;

@Data
public class ContactBean {
private String name;
private int number;
private String group_name;
}
