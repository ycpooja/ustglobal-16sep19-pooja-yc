package com.ustglobal.contact.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class ContactImpl implements ContactDao {

	@Override
	public ArrayList<ContactBean> getAllContactData() {
		String url="jdbc:mysql://localhost:3306/contactfile?user=root&password=root";
		String sql="select * from contact";
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			ArrayList<ContactBean> result=new ArrayList<ContactBean>();
			while(rs.next()) {
				ContactBean bean=new ContactBean();
				bean.setName(rs.getString("name"));
				bean.setNumber(rs.getInt("number"));
				bean.setGroup_name(rs.getString("group_name"));
				result.add(bean);
			}
			return result;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(stmt!=null) {
					stmt.close();
				}
				if(rs!=null) {
					rs.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public String displayCallingList(String name) {
		String url="jdbc:mysql://localhost:3306/contactfile?user=root&password=root";
		String sql="select * from contact where name=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs=pstmt.executeQuery(sql);
			if(rs.next()) {
				ContactBean bean=new ContactBean();
				System.out.println("name is"+bean.getName());
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(rs!=null) {
					rs.close();
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return name;
	}
	
	@Override
	public String messageToTheContact(String name) {
		String url="jdbc:mysql://localhost:3306/contactfile?user=root&password=root";
		String sql="select * from contact where name=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs=pstmt.executeQuery(sql);
			if(rs.next()) {
				ContactBean bean=new ContactBean();
				System.out.println("name is"+bean.getName());
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(rs!=null) {
					rs.close();
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return name;
	}
	

	@Override
	public String DeleteContactData(String name) {
		String url="jdbc:mysql://localhost:3306/contactfile?user=root&password=root";
		String sql="delete from contact where name=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			int count=pstmt.executeUpdate();
			if(count>0) {
				System.out.println(count+"rows deleted");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return name;
	}

	@Override
	public ContactBean insertContactData(String name, int number, String group_name) {
		String url="jdbc:mysql://localhost:3306/contactfile?user=root&password=root";
		String sql="insert into contact values(?,?,?)";
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setInt(2, number);
			pstmt.setString(3, group_name);
			int count=pstmt.executeUpdate();
			if(count>0) {
				System.out.println(count+"rows inserted");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}


	@Override
	public ContactBean updateContactData(String name, int number, String group_name) {
		String url="jdbc:mysql://localhost:3306/ust_ty_db?user=root&password=root";
		String sql="update contact set number=?,group_name=? where name=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url);
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(3, name);
			pstmt.setInt(1, number);
			pstmt.setString(2, group_name);
			int count=pstmt.executeUpdate();
			if(count>0) {
			ContactBean bean=new ContactBean();	
			System.out.println(count+"rows updated");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
	
		
	}
		return null;
	}
}
	
