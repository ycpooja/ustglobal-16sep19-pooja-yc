package com.ustglobal.contact.dao;

import java.util.ArrayList;
import java.util.Scanner;

public class app {
	public static void main(String[] args) {
		System.out.println("press 1 to show all contacts");
		System.out.println("press 2 to search for contact");
		System.out.println("press 3 to operate on contact");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();

		switch(ch) {
		case 1:
			ContactDao dao=ContactFactory.getAllContactDao();
			ArrayList<ContactBean> bean=dao.getAllContactData();
			for (ContactBean contactBean : bean) {
				System.out.println("name is"+contactBean.getName());
				System.out.println("number is"+contactBean.getNumber());
				System.out.println("group_name is"+contactBean.getGroup_name());	
			}
			break;
		case 2:
			System.out.println("press 1 to call");
			System.out.println("press 2 to message");
			System.out.println("press 3 to exit");

			Scanner sc1=new Scanner(System.in);
			int ch1=sc.nextInt();

			switch(ch1) {
			case 1: ContactDao dao4=ContactFactory.getAllContactDao();
			String name4=sc.next();
			System.out.println("end the call");
			
			break;

			case 2: ContactDao dao5=ContactFactory.getAllContactDao();
			String name5=sc.next();
			System.out.println("message sent");
			
			break;
	
			case 3:	System.out.println("press 1 to show all contacts");
			System.out.println("press 2 to search for contact");
			System.out.println("press 3 to operate on contact");
			
			}
			break;
			
		case 3:
			System.out.println("press 1 to insert");
			System.out.println("press 2 to delete");
			System.out.println("press 3 to update");

			Scanner sc2=new Scanner(System.in);
			int ch2=sc.nextInt();

			switch(ch2) {
			case 1: ContactDao dao1=ContactFactory.getAllContactDao();
			String name=sc.next();
			int number=sc.nextInt();
			String group_name=sc.next();
			ContactBean bean1=dao1.insertContactData(name, number, group_name);
			if(bean1!=null){
				System.out.println("successfully inserted");
			}
			break;

			case 2: ContactDao dao3=ContactFactory.getAllContactDao();
			String name3=sc.next();
			String bean3=dao3.DeleteContactData(name3);
			if(bean3!=null) {
				System.out.println("successfully deleted");
			}
			break;
			
			case 3: ContactDao dao2=ContactFactory.getAllContactDao();
			String name1=sc.next();
			int number1=sc.nextInt();
			String group_name1=sc.next();
			ContactBean bean2=dao2.updateContactData(name1, number1, group_name1);
			if(bean2!=null){
				System.out.println("successfully updated");
			}
			break;

			}
		}
	}
}