package com.ustglobal.contact.dao;

import java.util.ArrayList;

public interface ContactDao {

	public ArrayList<ContactBean> getAllContactData();
	public String displayCallingList(String name);
	public String messageToTheContact(String name);
	public String DeleteContactData(String name);
	public ContactBean insertContactData(String name,int number,String group_name);
	public ContactBean updateContactData(String name,int number,String group_name);
	
	
}
