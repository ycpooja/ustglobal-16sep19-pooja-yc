package com.ustglobal.contact.dao;

public class ContactFactory {

	private ContactFactory() {
		
	}
	
	public static ContactDao getAllContactDao() {
		return new ContactImpl();
	}
}
